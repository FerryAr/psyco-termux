/* This file was automatically created by ./mksignames.
   Do not edit.  Edit support/mksignames.c instead. */

/* A translation list so we can be polite to our users. */
extern char *signal_names[];

extern void initialize_signames PARAMS((void));

